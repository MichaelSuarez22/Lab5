package cr.ac.una.controlfinanciero

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.DatePicker
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*

class CrearMovimiento : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crear_movimiento)

        val datePicker = findViewById<DatePicker>(R.id.datePicker)
        val spinnerTipo = findViewById<Spinner>(R.id.spinnerTipo)
        val editTextMonto = findViewById<EditText>(R.id.editTextMonto)
        val botonInsertar = findViewById<Button>(R.id.botonInsertar)
        val botonSalir = findViewById<Button>(R.id.botonSalir)

        // Configurar el selector de fecha para que muestre la fecha actual
        val cal = Calendar.getInstance()
        datePicker.init(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH), null)

        // Configurar el spinner con los valores de tipo
        val tipos = arrayOf("Crédito", "Débito")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, tipos)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerTipo.adapter = adapter

        botonInsertar.setOnClickListener {
            val year = datePicker.year
            val month = datePicker.month
            val day = datePicker.dayOfMonth
            val fecha = "$year-${month + 1}-$day" // Formato YYYY-MM-DD

            val tipo = if (spinnerTipo.selectedItemPosition == 0) 1 else 2
            val monto = editTextMonto.text.toString().toDoubleOrNull()

            if (monto != null && monto >= 0) {
                val intent = Intent()
                intent.putExtra("fecha", fecha)
                intent.putExtra("tipo", tipo)
                intent.putExtra("monto", String.format("%.2f", monto)) // Redondear a 2 decimales
                setResult(Activity.RESULT_OK, intent)
                finish()
            } else {
                Toast.makeText(this, "Ingrese un monto válido", Toast.LENGTH_SHORT).show()
            }
        }

        botonSalir.setOnClickListener {
            setResult(Activity.RESULT_CANCELED)
            finish()
        }
    }
}

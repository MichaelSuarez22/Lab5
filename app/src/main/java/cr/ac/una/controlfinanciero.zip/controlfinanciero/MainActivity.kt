package cr.ac.una.controlfinanciero

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import androidx.activity.result.contract.ActivityResultContracts
import cr.ac.una.controlfinanciero.adapter.MovimientoAdapter
import cr.ac.una.controlfinanciero.controller.MovimientoController
import cr.ac.una.controlfinanciero.entity.Movimiento

class MainActivity : AppCompatActivity() {
    private lateinit var movimientoController: MovimientoController
    private lateinit var adapter: MovimientoAdapter

    private val activityResultLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data: Intent? = result.data
            if (data != null) {
                val fecha = data.getStringExtra("fecha") ?: ""
                val tipo = data.getIntExtra("tipo", 1)
                val monto = data.getStringExtra("monto")?.toDoubleOrNull() ?: 0.0
                val movimiento = Movimiento(monto, tipo, fecha)
                MovimientoController.insertMovimiento(movimiento)
                adapter.notifyDataSetChanged()
            }
        }

    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        movimientoController = MovimientoController
        adapter = MovimientoAdapter(this, MovimientoController.movimientos)

        val listaMovimientos = findViewById<ListView>(R.id.listaMovimientos)
        listaMovimientos.adapter = adapter

        val botonNuevo = findViewById<Button>(R.id.botonNuevo)
        botonNuevo.setOnClickListener {
            activityResultLauncher.launch(Intent(this, CrearMovimiento::class.java))
        }

        listaMovimientos.setOnItemClickListener { parent, view, position, id ->
            val movimiento = adapter.getItem(position)
            val intent = Intent(this, DetalleMovimiento::class.java)
            intent.putExtra("movimiento", movimiento)
            startActivity(intent)
        }
    }
}

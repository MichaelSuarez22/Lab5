package cr.ac.una.controlfinanciero.entity

import java.io.Serializable

data class Movimiento(var monto: Double, var tipo: Int, var fecha: String) : Serializable
